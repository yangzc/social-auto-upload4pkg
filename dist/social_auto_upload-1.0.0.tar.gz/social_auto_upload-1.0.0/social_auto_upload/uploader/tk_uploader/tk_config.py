
class Tk_Locator(object):
    tk_iframe = '[data-tt="Upload_index_iframe"]'
    default = 'body'
