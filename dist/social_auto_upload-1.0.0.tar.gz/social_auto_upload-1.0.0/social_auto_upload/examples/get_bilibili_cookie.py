# cd uploader/bilibili_uploader
# biliup.exe -u account.json login
